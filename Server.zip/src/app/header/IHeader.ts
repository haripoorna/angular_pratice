export interface IHeader{
  LoadPage(data:String);
}
