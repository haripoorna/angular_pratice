export class Country{
    name:String
    code:String

}