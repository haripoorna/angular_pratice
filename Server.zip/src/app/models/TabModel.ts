export const Tabs =
  ["Home","Register","Login","Products","Cart"];
